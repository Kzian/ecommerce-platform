test('API sanity check', () => {
  expect(1 + 1).toBe(2);
});

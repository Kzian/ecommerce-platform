const express = require('express');
const cors = require('cors'); // ✅ add this line

const app = express();

// ✅ enable CORS for all routes
app.use(cors());
app.use(express.json());

app.get('/products', (req, res) => {
  res.json([{ id: 1, name: 'Book', price: 10 }]);
});

// Health check endpoint for Elastic Beanstalk
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'UP', message: 'Backend is healthy 🚀' });
});


const PORT = process.env.PORT || 3000;
if (require.main === module) {
  app.listen(PORT, () => console.log(`API running on port ${PORT}`));
}

module.exports = app;
